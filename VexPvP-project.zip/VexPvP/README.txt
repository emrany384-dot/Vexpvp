VexPvP starter project
Target: Paper 1.21.4 / Java 21

Project files:
- pom.xml
- src/main/resources/plugin.yml
- src/main/resources/config.yml
- src/main/java/net/vexpvp/VexPvP.java

Build with Maven in an environment with internet access:
  mvn package

Expected output:
  target/VexPvP-1.0.0.jar

Then upload the JAR to the server's plugins folder and restart the server.
Run /vexsetup in-game to set/build the spawn.

IMPORTANT:
This project could not be compiled in the current environment because Maven is not installed and external network access is unavailable. Treat it as unverified source code, not a ready-to-upload JAR. Test on a temporary server first.

Feature limitations in this starter:
- Queue NPCs are not implemented as clickable NPCs; queues use /queue <mode>.
- Arena creation is basic and arenas are not reset between matches.
- Player inventories are not backed up/restored after duels.
- Ranks are held in memory only and do not persist through restart.
- Geyser/Floodgate is needed separately for Bedrock connectivity.
