VexPvP - Paper 1.21.4 starter plugin

This is a starter project, not a fully tested production plugin. The current code includes basic commands, queue matchmaking, starter kits, a simple generated courtyard, and spawn protection. It does NOT yet implement clickable queue NPCs, separate/resettable arenas, or safe restoration of players' original inventories after a duel. Test on a temporary server first.

EASIEST BUILD METHOD (browser only):
1. Create a new public or private GitHub repository named VexPvP.
2. Upload the CONTENTS of this folder to the repository (not the outer folder itself).
3. Open the repository's Actions tab and select "Build VexPvP plugin".
4. If it has not run automatically, click "Run workflow".
5. Open the completed workflow run, find Artifacts, and download VexPvP-1.0.0.
6. Extract the downloaded artifact ZIP. It contains VexPvP-1.0.0.jar.
7. Upload that .jar to the GameHost plugins page and restart the server.

The GitHub Actions workflow compiles using Java 21 and Maven and uploads the resulting JAR as an artifact.
