package net.vexpvp;

import org.bukkit.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

public final class VexPvP extends JavaPlugin implements Listener, CommandExecutor {
    private static final List<String> MODES = List.of("sword", "crystal", "netheritepot", "uhc", "mace", "spearmace");
    private static final List<String> RANKS = List.of("Owner", "Co-Owner", "SrMod", "Mod", "Helper", "Vex+");
    private final Map<String, Deque<UUID>> queues = new HashMap<>();
    private final Map<UUID, UUID> opponents = new HashMap<>();
    private final Set<UUID> fighting = new HashSet<>();
    private final Map<UUID, String> ranks = new HashMap<>();
    private Location spawn;

    @Override public void onEnable() {
        saveDefaultConfig();
        spawn = getConfig().getLocation("spawn");
        for (String mode : MODES) queues.put(mode, new ArrayDeque<>());
        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("spawn", "queue", "leavequeue", "vexsetup", "vexrank")) {
            Objects.requireNonNull(getCommand(name), "Missing command in plugin.yml: " + name).setExecutor(this);
        }
        getLogger().info("VexPvP 1.0.0 enabled for Paper 1.21.x");
    }

    @Override public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (fighting.contains(player.getUniqueId())) {
                player.getInventory().clear();
                player.setGameMode(GameMode.SURVIVAL);
                if (spawn != null) player.teleport(spawn);
            }
        }
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("vexsetup")) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Run this in-game."); return true; }
            if (!player.isOp() && !player.hasPermission("vexpvp.setup")) { player.sendMessage("§cNo permission."); return true; }
            spawn = player.getLocation().getBlock().getLocation().add(0.5, 0, 0.5);
            getConfig().set("spawn", spawn); saveConfig(); buildMedievalSpawn(spawn);
            player.sendMessage("§6§lVexPvP §7» §aSpawn saved and courtyard built."); return true;
        }
        if (cmd.equals("spawn")) {
            if (!(sender instanceof Player p)) return true;
            if (fighting.contains(p.getUniqueId())) { p.sendMessage("§cYou cannot leave a duel with /spawn."); return true; }
            teleportToSpawn(p); return true;
        }
        if (cmd.equals("queue")) {
            if (!(sender instanceof Player p)) return true;
            if (args.length != 1 || !MODES.contains(args[0].toLowerCase(Locale.ROOT))) {
                p.sendMessage("§cUse /queue <sword|crystal|netheritepot|uhc|mace|spearmace>"); return true;
            }
            joinQueue(p, args[0].toLowerCase(Locale.ROOT)); return true;
        }
        if (cmd.equals("leavequeue")) {
            if (!(sender instanceof Player p)) return true;
            removeFromQueues(p.getUniqueId()); p.sendMessage("§eYou left the queue."); return true;
        }
        if (cmd.equals("vexrank")) {
            if (!sender.hasPermission("vexpvp.rank")) { sender.sendMessage("§cNo permission."); return true; }
            if (args.length != 2) { sender.sendMessage("§cUsage: /vexrank <player> <rank>"); return true; }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) { sender.sendMessage("§cThat player must be online."); return true; }
            String wanted = args[1].replace("-", "");
            String rank = RANKS.stream().filter(r -> r.replace("-", "").equalsIgnoreCase(wanted)).findFirst().orElse(null);
            if (rank == null) { sender.sendMessage("§cRanks: Owner, Co-Owner, SrMod, Mod, Helper, Vex+"); return true; }
            ranks.put(target.getUniqueId(), rank);
            target.setPlayerListName("§6[" + rank + "] §f" + target.getName());
            target.sendMessage("§aYour VexPvP rank is now " + rank + "."); sender.sendMessage("§aRank updated."); return true;
        }
        return false;
    }

    private void teleportToSpawn(Player p) {
        if (spawn == null || spawn.getWorld() == null) { p.sendMessage("§cSpawn isn't set. Ask an admin to run /vexsetup."); return; }
        p.teleport(spawn); p.setFallDistance(0); p.sendMessage("§6§lVexPvP §7» §eTeleported to spawn.");
    }

    private void buildMedievalSpawn(Location center) {
        World w = center.getWorld(); if (w == null) return;
        int cx = center.getBlockX(), cy = center.getBlockY() - 1, cz = center.getBlockZ();
        for (int x=-15;x<=15;x++) for (int z=-15;z<=15;z++) w.getBlockAt(cx+x,cy,cz+z).setType(Material.STONE_BRICKS);
        for (int x=-16;x<=16;x++) for (int y=0;y<=5;y++) {
            if (x < -12 || x > 12) { w.getBlockAt(cx+x,cy+y,cz-16).setType(Material.STONE_BRICKS); w.getBlockAt(cx+x,cy+y,cz+16).setType(Material.STONE_BRICKS); }
        }
        for (int z=-16;z<=16;z++) for (int y=0;y<=5;y++) {
            w.getBlockAt(cx-16,cy+y,cz+z).setType(Material.STONE_BRICKS); w.getBlockAt(cx+16,cy+y,cz+z).setType(Material.STONE_BRICKS);
        }
        int[][] towers={{-16,-16},{-16,16},{16,-16},{16,16}};
        for (int[] t:towers) {
            for (int y=0;y<=8;y++) for (int x=-2;x<=2;x++) for (int z=-2;z<=2;z++) if (Math.abs(x)==2 || Math.abs(z)==2) w.getBlockAt(cx+t[0]+x,cy+y,cz+t[1]+z).setType(Material.STONE_BRICKS);
            for (int x=-3;x<=3;x++) for (int z=-3;z<=3;z++) w.getBlockAt(cx+t[0]+x,cy+9,cz+t[1]+z).setType(Material.DARK_OAK_PLANKS);
        }
        for (int i=0;i<MODES.size();i++) { int x=-10+i*4; w.getBlockAt(cx+x,cy+1,cz+5).setType(Material.EMERALD_BLOCK); w.getBlockAt(cx+x,cy+2,cz+5).setType(Material.LANTERN); }
        w.getBlockAt(cx,cy+1,cz).setType(Material.BEACON); w.getBlockAt(cx,cy+2,cz).setType(Material.AIR); w.getBlockAt(cx,cy+3,cz).setType(Material.AIR);
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Player p=e.getPlayer(); Bukkit.getScheduler().runTaskLater(this, () -> { if (p.isOnline() && spawn != null) teleportToSpawn(p); }, 1L);
        String rank = ranks.get(p.getUniqueId()); if (rank != null) p.setPlayerListName("§6["+rank+"] §f"+p.getName());
    }

    private void joinQueue(Player p, String mode) {
        UUID id=p.getUniqueId(); if (fighting.contains(id)) { p.sendMessage("§cYou are already in a duel."); return; }
        removeFromQueues(id); Deque<UUID> q=queues.get(mode); UUID opponentId=null;
        while (!q.isEmpty()) { UUID candidate=q.pollFirst(); Player other=Bukkit.getPlayer(candidate); if (other!=null && other.isOnline() && !candidate.equals(id) && !fighting.contains(candidate)) { opponentId=candidate; break; } }
        if (opponentId==null) { q.addLast(id); p.sendMessage("§eSearching for a "+mode+" opponent..."); return; }
        Player other=Bukkit.getPlayer(opponentId); if (other==null) { q.addLast(id); return; } startMatch(p,other,mode);
    }
    private void removeFromQueues(UUID id) { for (Deque<UUID> q:queues.values()) q.remove(id); }

    private void startMatch(Player a, Player b, String mode) {
        fighting.add(a.getUniqueId()); fighting.add(b.getUniqueId()); opponents.put(a.getUniqueId(),b.getUniqueId()); opponents.put(b.getUniqueId(),a.getUniqueId());
        Location base=spawn != null ? spawn : a.getWorld().getSpawnLocation();
        Location one=base.clone().add(35,2,0), two=base.clone().add(-35,2,0);
        // Simple temporary match platforms. Separate arenas/resetting are not yet implemented.
        buildArenaPlatform(one); buildArenaPlatform(two);
        a.teleport(one); b.teleport(two); giveKit(a,mode); giveKit(b,mode);
        a.sendMessage("§6§lVexPvP §7» §aDuel started: "+mode); b.sendMessage("§6§lVexPvP §7» §aDuel started: "+mode);
    }
    private void buildArenaPlatform(Location l) { World w=l.getWorld(); if(w==null)return; for(int x=-5;x<=5;x++)for(int z=-5;z<=5;z++)w.getBlockAt(l.getBlockX()+x,l.getBlockY()-1,l.getBlockZ()+z).setType(Material.SMOOTH_STONE); }

    private void giveKit(Player p,String mode) {
        p.getInventory().clear(); p.getInventory().setArmorContents(null); p.setHealth(20); p.setFoodLevel(20); p.setFireTicks(0);
        p.getInventory().setHelmet(armor(Material.NETHERITE_HELMET)); p.getInventory().setChestplate(armor(Material.NETHERITE_CHESTPLATE)); p.getInventory().setLeggings(armor(Material.NETHERITE_LEGGINGS)); p.getInventory().setBoots(armor(Material.NETHERITE_BOOTS));
        switch(mode) {
            case "sword" -> p.getInventory().addItem(new ItemStack(Material.NETHERITE_SWORD),new ItemStack(Material.GOLDEN_APPLE,8),new ItemStack(Material.COBWEB,4));
            case "crystal" -> { p.getInventory().addItem(new ItemStack(Material.END_CRYSTAL,64),new ItemStack(Material.OBSIDIAN,64),new ItemStack(Material.TOTEM_OF_UNDYING,2),new ItemStack(Material.NETHERITE_SWORD)); p.getInventory().setItemInOffHand(new ItemStack(Material.TOTEM_OF_UNDYING)); }
            case "netheritepot" -> p.getInventory().addItem(new ItemStack(Material.NETHERITE_SWORD),new ItemStack(Material.SPLASH_POTION,32),new ItemStack(Material.GOLDEN_APPLE,8));
            case "uhc" -> p.getInventory().addItem(new ItemStack(Material.DIAMOND_SWORD),new ItemStack(Material.BOW),new ItemStack(Material.ARROW,32),new ItemStack(Material.GOLDEN_APPLE,6),new ItemStack(Material.WATER_BUCKET));
            case "mace" -> p.getInventory().addItem(new ItemStack(Material.MACE),new ItemStack(Material.WIND_CHARGE,64),new ItemStack(Material.ENDER_PEARL,16),new ItemStack(Material.GOLDEN_APPLE,16));
            case "spearmace" -> p.getInventory().addItem(new ItemStack(Material.MACE),new ItemStack(Material.TRIDENT),new ItemStack(Material.WIND_CHARGE,64),new ItemStack(Material.ENDER_PEARL,16));
        }
        p.addPotionEffect(new PotionEffect(PotionEffectType.SATURATION,20*60*60,0,false,false));
    }
    private ItemStack armor(Material type) { ItemStack item=new ItemStack(type); ItemMeta meta=item.getItemMeta(); if(meta!=null) { meta.addEnchant(Enchantment.PROTECTION,4,true); meta.addEnchant(Enchantment.UNBREAKING,3,true); item.setItemMeta(meta); } return item; }

    @EventHandler public void onDeath(PlayerDeathEvent e) {
        Player loser=e.getEntity(); UUID id=loser.getUniqueId(); if(!fighting.contains(id))return; e.getDrops().clear(); e.setDroppedExp(0);
        UUID opponentId=opponents.get(id); Player winner=opponentId==null?null:Bukkit.getPlayer(opponentId);
        if(winner!=null)winner.sendMessage("§aYou won the duel!");
        Bukkit.getScheduler().runTaskLater(this,()->finishMatch(id),1L);
    }
    private void finishMatch(UUID id) {
        UUID other=opponents.remove(id); fighting.remove(id);
        Player loser=Bukkit.getPlayer(id); if(loser!=null && loser.isOnline()) { loser.getInventory().clear(); loser.setGameMode(GameMode.SURVIVAL); teleportToSpawn(loser); }
        if(other!=null) { opponents.remove(other); fighting.remove(other); Player winner=Bukkit.getPlayer(other); if(winner!=null && winner.isOnline()) { winner.getInventory().clear(); winner.setGameMode(GameMode.SURVIVAL); teleportToSpawn(winner); } }
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) { UUID id=e.getPlayer().getUniqueId(); removeFromQueues(id); if(fighting.contains(id))finishMatch(id); }

    private boolean isProtected(Location l) { return spawn!=null && spawn.getWorld()!=null && l.getWorld()!=null && l.getWorld().equals(spawn.getWorld()) && l.distanceSquared(spawn)<=30*30; }
    @EventHandler public void onBreak(BlockBreakEvent e) { if(isProtected(e.getBlock().getLocation()))e.setCancelled(true); }
    @EventHandler public void onPlace(BlockPlaceEvent e) { if(isProtected(e.getBlock().getLocation()))e.setCancelled(true); }
    @EventHandler public void onDamage(EntityDamageEvent e) { if(e.getEntity() instanceof Player p && isProtected(p.getLocation()) && !fighting.contains(p.getUniqueId()))e.setCancelled(true); }
    @EventHandler public void onExplode(EntityExplodeEvent e) { e.blockList().removeIf(b->isProtected(b.getLocation())); }
    @EventHandler public void onIgnite(BlockIgniteEvent e) { if(isProtected(e.getBlock().getLocation()))e.setCancelled(true); }
    @EventHandler public void onInteract(PlayerInteractEvent e) { if(isProtected(e.getPlayer().getLocation()) && !fighting.contains(e.getPlayer().getUniqueId()) && e.getClickedBlock()!=null && e.getClickedBlock().getType()==Material.BEACON) { e.setCancelled(true); e.getPlayer().sendMessage("§eJoin a duel with /queue <mode>."); } }
    @EventHandler public void onPvP(EntityDamageByEntityEvent e) { if(e.getEntity() instanceof Player victim && e.getDamager() instanceof Player attacker && (!fighting.contains(attacker.getUniqueId()) || !Objects.equals(opponents.get(attacker.getUniqueId()),victim.getUniqueId())))e.setCancelled(true); }
}
